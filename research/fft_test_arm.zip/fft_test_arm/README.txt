This test c++ program shows how to detect image shift by FFT.
The programs runs on a Android phone through adb shell.

To build the program, one needs the standalone NDK toolchain of Android.
The FFT calculation is done in OpenCV code. Therefore, OpenCV version 2.4.7 is included.
In a terminal window, run src/build_clang.sh to build the excutable.
After building, please adb push src/bin to /data/local/ and run excutable test with command line
through adb shell. 
