#!/bin/bash

#Create directory for binary excutable. 
mkdir -p bin
cp ./test.jpg ./bin/
cp ./libgnustl_shared.so ./bin/

#Test if android standalone toolchain is properly set.
if hash arm-linux-androideabi-gcc 2>/dev/null; then
   echo "arm-linux-androideabi-gcc existing..."
   which arm-linux-androideabi-gcc
else
    echo "Android standalone toolchain cannot be found!"
    echo "Please update PATH to include the bin directory of the standalone toolchain."
    exit
fi
arm-linux-androideabi-clang++ -fPIE -pie ./test.cpp \
                  -o ./bin/test -std=c++11 -Wall \
                  -I../opencv247/include \
                  -O3 -landroid -llog -lz -lm -ldl -lstdc++ \
                  -L../opencv247/libs/armeabi-v7a/ -lopencv_imgproc -lopencv_highgui  -lopencv_core \
                  -llibpng -llibtiff -llibjpeg -llibjasper -lIlmImf \
                  -O3

#Building complete
echo "Compile complete ......"
echo "One can test with android device. use /data/local directory only please."

 
