#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
using namespace cv;

void getImageShift(float *shiftX, float *shiftY, float *maxValue, Mat &ref,
                   Mat &curPic) {
  if (ref.empty()) {
    return;
  }
  Mat padded; // expand input image to optimal size
  int32_t m = getOptimalDFTSize(ref.rows);
  int32_t n = getOptimalDFTSize(ref.cols); // on the border add zero values
  // FFT for 1st image
  copyMakeBorder(ref, padded, 0, m - ref.rows, 0, n - ref.cols, BORDER_CONSTANT,
                 Scalar::all(0));
  Mat planes[] = {padded, Mat::zeros(padded.size(), CV_32F)};
  Mat complexI0;
  merge(planes, 2, complexI0); // Add to the expanded another plane with zeros
  dft(complexI0, complexI0); // this way the result may fit in the source matrix
  // FFT for 2nd image
  copyMakeBorder(curPic, padded, 0, m - curPic.rows, 0, n - curPic.cols,
                 BORDER_CONSTANT, Scalar::all(0));
  Mat complexI1;
  merge(planes, 2, complexI1); // Add to the expanded another plane with zeros
  dft(complexI1, complexI1); // this way the result may fit in the source matrix
                             // calculating the idft
  mulSpectrums(complexI0, complexI1, complexI0, 0, true);
  Mat inverseTransform;
  dft(complexI0, inverseTransform, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT);
  double minVal;
  double maxVal;
  Point minLoc;
  Point maxLoc;
  // Get max location of output
  minMaxLoc(inverseTransform, &minVal, &maxVal, &minLoc, &maxLoc);
  // Report the result.
  *shiftX = maxLoc.x;
  *shiftY = maxLoc.y;
  *maxValue = maxVal;
  return;
}

// The kernal is centered at mat center and is scaled in each directions
// For example, if the picture is 640x480, horizonally, the sigma is
// 640*sigmaRatio Vertically, the sigma is 480*sigmaRatio. The result is
// nomalized to (0,1);
void createNormalizedGaussionKernal(Mat &outKernal, float sigmaRatio) {
  // FIXME, no verification of input.
  size_t n = getOptimalDFTSize(outKernal.rows);
  size_t m = getOptimalDFTSize(outKernal.cols);
  float cx = static_cast<float>(m) / 2.0f - 0.5f;
  float cy = static_cast<float>(n) / 2.0f - 0.5f;
  float ratio = static_cast<float>(n) / static_cast<float>(m);
  float sigma = sigmaRatio * static_cast<float>(n);
  for (size_t i = 0; i < n; i++) {
    for (size_t j = 0; j < m; j++) {
      float distance = (static_cast<float>(j) - cx) * ratio;
      distance = distance * distance;
      distance += (static_cast<float>(i) - cy) * (static_cast<float>(i) - cy);
      float distr = exp(-distance / 2.0f / sigma / sigma);
      outKernal.at<float>(i, j) = distr;
    }
  }
  normalize(outKernal, outKernal, 0, 1, CV_MINMAX);
}

int main(int argc, char **argv) {
  const char *filename = argc >= 2 ? argv[1] : "test.jpg";

  Mat I = imread(filename, CV_LOAD_IMAGE_GRAYSCALE);
  if (I.empty()) {
    return -1;
  }

  float shiftX;
  float shiftY;
  float maxValue;
  // Create 2 images, one is the shift of another
  Mat input0 = I(Rect(0, 0, 512, 320));
  Mat input1 = I(Rect(20, 15, 512, 320));

  Mat gaussianMat = Mat::zeros(input0.size(), CV_32F);
  createNormalizedGaussionKernal(gaussianMat, 0.4f);

  Mat input_a = Mat_<float>(input0);
  Mat input_b = Mat_<float>(input1);
  normalize(input_a, input_a, -1, 1, CV_MINMAX);
  normalize(input_b, input_b, -1, 1, CV_MINMAX);

  input_a = input_a.mul(gaussianMat);
  input_b = input_b.mul(gaussianMat);
  for (size_t i = 0; i < 1000; i++) {
    getImageShift(&shiftX, &shiftY, &maxValue, input_a, input_b);
  }
  std::cout << "X shift " << shiftX << "\n";
  std::cout << "Y shift " << shiftY << "\n";
}
