CamFrameGrabber.zip includes an Android project that builds an aar,  which is an android library called cameralibrary.

The library defines a class called CameraHandler. It does 3 things.

Start FrontView Camera in 640x480 resolution
Stop Camera
Get Current Frame in YUV NV21 format. The picture is saved in a ByteBuffer.


File MainActivity.java showes  how to use it.

