package com.example.camframegrabber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

import com.example.cameralibrary.CameraHandler;
import java.nio.ByteBuffer;

public class MainActivity extends AppCompatActivity {
    Button mButton0;
    Button mButton1;
    SurfaceView mCameraView;
    CameraHandler mCameraHandler;
    ByteBuffer myPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButton0 = (Button) findViewById(R.id.button0);
        mButton1 = (Button) findViewById(R.id.button1);
        mCameraView = (SurfaceView) findViewById(R.id.cameraView);
        mButton0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create cameraHandler
                if ( mCameraHandler != null ) {
                    mCameraHandler.stopCameraFromOwner();
                    mCameraHandler = null;
                }
                mCameraHandler = new CameraHandler(getBaseContext(), mCameraView);
                //Start Camera
                mCameraHandler.startCameraFromOwner();
            }
        });
        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get current pic from CameraHandler
                myPic = mCameraHandler.getCurrentPic();
                //Stop the camera.
                if (mCameraHandler != null) {
                    mCameraHandler.stopCameraFromOwner();
                    mCameraHandler = null;
                }
            }
        });
    }
}
